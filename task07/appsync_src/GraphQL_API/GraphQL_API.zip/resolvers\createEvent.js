import { util } from '@aws-appsync/utils';

export function request(ctx) {
  const id = util.autoId();
  const createdAt = util.time.nowISO8601();
  const payLoad = JSON.parse(ctx.arguments.payLoad);

  return {
    operation: 'PutItem',
    key: util.dynamodb.toMapValues({ id }),
    attributeValues: util.dynamodb.toMapValues({
      userId: ctx.arguments.userId,
      createdAt: createdAt,
      payLoad: payLoad
    })
  };
}

export function response(ctx) {
  return ctx.result;
}